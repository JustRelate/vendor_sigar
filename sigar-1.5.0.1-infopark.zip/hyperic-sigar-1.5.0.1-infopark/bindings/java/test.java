import org.hyperic.sigar.*;

public class test {

    public static void main(String[] args) throws Exception {
        Sigar sigar = new Sigar();

        long[] pids = sigar.getProcList();

        for (int i=0; i<pids.length; i++) {
            String user;
            try {
                ProcCredName cred = sigar.getProcCredName(pids[i]);
                user = cred.getUser();
            } catch (SigarException e) {
                user = e.getMessage();
            }
            System.out.println(pids[i] + "=" + user);
        }

        sigar.close();
    }
}
